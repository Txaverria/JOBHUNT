class Job {
    constructor(title, company, type, modality, area, salary, deadline) {
      this.title = title;
      this.company = company;
      this.type = type;
      this.modality = modality;
      this.area = area;
      this.salary = salary;
      this.deadline = deadline;
    }
  
    render() {
      return `
        <div class="job-card">
          <img src="https://via.placeholder.com/50" alt="${this.title}">
          <div class="details">
            <h3>${this.title}</h3>
            <p>${this.company} (${this.type})</p>
            <p>${this.modality}</p>
            <p>${this.area} - $${this.salary}</p>
          </div>
          <button>Solicitar</button>
        </div>
      `;
    }
  }
  
  class JobBoard {
    constructor() {
      this.jobs = [];
      this.filteredJobs = [];
    }
  
    addJob(job) {
      this.jobs.push(job);
      this.filteredJobs = [...this.jobs];
    }
  
    filterJobs({ type, modality, area }) {
      this.filteredJobs = this.jobs.filter(job => {
        return (
          (type === "" || job.type === type) &&
          (modality === "" || job.modality === modality) &&
          (area === "" || job.area === area)
        );
      });
      this.render();
    }
  
    render() {
      const container = document.getElementById("jobsContainer");
      container.innerHTML = this.filteredJobs.map(job => job.render()).join("");
    }
  }
  
  const jobBoard = new JobBoard();
  
  // Add sample jobs
  jobBoard.addJob(new Job("Desarrollador Web", "Empresa A", "Tiempo Completo", "Remoto", "Tecnología", "2000", "30/11/2024"));
  jobBoard.addJob(new Job("Diseñador UX", "Empresa B", "Medio Tiempo", "Presencial", "Diseño", "1500", "25/11/2024"));
  jobBoard.addJob(new Job("Analista", "Empresa C", "Tiempo Completo", "Remoto", "Administración", "1800", "20/11/2024"));
  
  jobBoard.render();
  
  document.getElementById("clearFilters").addEventListener("click", () => {
    document.getElementById("jobType").value = "";
    document.getElementById("modality").value = "";
    document.getElementById("area").value = "";
    jobBoard.filterJobs({ type: "", modality: "", area: "" });
  });
  
  document.getElementById("jobType").addEventListener("change", e => {
    jobBoard.filterJobs({
      type: e.target.value,
      modality: document.getElementById("modality").value,
      area: document.getElementById("area").value,
    });
  });
  
  document.getElementById("modality").addEventListener("change", e => {
    jobBoard.filterJobs({
      type: document.getElementById("jobType").value,
      modality: e.target.value,
      area: document.getElementById("area").value,
    });
  });
  
  document.getElementById("area").addEventListener("change", e => {
    jobBoard.filterJobs({
      type: document.getElementById("jobType").value,
      modality: document.getElementById("modality").value,
      area: e.target.value,
    });
  });
  




  class Modal {
    constructor() {
      this.steps = Array.from(document.querySelectorAll(".step"));
      this.currentStep = 0;
  
      // Botones
      this.nextButtons = document.querySelectorAll("#nextStep1, #nextStep2");
      this.prevButtons = document.querySelectorAll("#prevStep2, #prevStep3");
      this.submitButton = document.getElementById("submit");
      this.doneButton = document.getElementById("done");
  
      this.bindEvents();
    }
  
    bindEvents() {
      this.nextButtons.forEach((button) =>
        button.addEventListener("click", () => this.next())
      );
      this.prevButtons.forEach((button) =>
        button.addEventListener("click", () => this.prev())
      );
      this.submitButton.addEventListener("click", () => this.submit());
      this.doneButton.addEventListener("click", () => this.close());
    }
  
    next() {
      this.steps[this.currentStep].classList.remove("active");
      this.currentStep++;
      this.steps[this.currentStep].classList.add("active");
    }
  
    prev() {
      this.steps[this.currentStep].classList.remove("active");
      this.currentStep--;
      this.steps[this.currentStep].classList.add("active");
    }
  
    submit() {
      const email = document.getElementById("email").value;
      const phone = document.getElementById("phone").value;
      const salary = document.getElementById("salaryExpectation").value || "No especificado";
  
      const review = document.getElementById("review");
      review.innerHTML = `
        <p>Email: ${email}</p>
        <p>Teléfono: ${phone}</p>
        <p>Salario esperado: ${salary}</p>
      `;
      this.next();
    }
  
    close() {
      document.getElementById("modal").style.display = "none";
      this.steps[this.currentStep].classList.remove("active");
      this.currentStep = 0;
      this.steps[0].classList.add("active");
    }
  
    open() {
      document.getElementById("modal").style.display = "flex";
    }
  }
  
  const modal = new Modal();
  document.querySelectorAll(".job-card button").forEach((button) =>
    button.addEventListener("click", () => modal.open())
  );
  


  document.getElementById('done').addEventListener('click', function() {
    document.getElementById('confirmation-illustration').style.display = 'block';
  
    setTimeout(() => {
      document.getElementById('confirmation-illustration').style.opacity = '1';
    }, 100);
  
  });
  