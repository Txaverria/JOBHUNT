const editButton = document.getElementById("edit-profile");
const modal = document.getElementById("edit-modal");
const closeModalButton = document.getElementById("close-modal");
const saveChangesButton = document.getElementById("save-changes");

editButton.addEventListener("click", () => {
  modal.classList.remove("hidden");
});

closeModalButton.addEventListener("click", () => {
  modal.classList.add("hidden");
});

saveChangesButton.addEventListener("click", () => {
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;
  const preferences = document.getElementById("preferences").value;

  document.querySelector("#email-display").textContent = email;
  document.querySelector("#phone-display").textContent = phone;
  document.querySelector("#preferences-display").textContent = preferences;

  modal.classList.add("hidden");
});


document.getElementById('save-changes').addEventListener('click', function() {
  alert('Cambios guardados correctamente.');

  setTimeout(function() {
      alert('Formulario enviado correctamente.');
  }, 500);
});
 